package com.example.bootjdbctemplateboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootJdbcTemplateBoardApplicationTests {

	@Test
	void contextLoads() {
	}

}
